"use client";

import { ConnectButton } from '@rainbow-me/rainbowkit';

export function Connection() {
    return (
        <ConnectButton />
    )
}