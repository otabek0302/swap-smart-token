'use client';

import { useState } from 'react';
import { useWriteContract, useAccount } from 'wagmi';
import { parseUnits } from 'viem/utils';
import { contracts } from '@/contracts';

const FACTORY_ADDRESS = '0x8E2b68f204B288DC3fB59927A75634A9cf827eA4' as `0x${string}`;

const TOKENS = [
  { name: 'AOG', address: '0xCDD3FC74FAf25fE5656ad5C1ea02ec701298E952' },
  { name: 'AOS', address: '0xC947A001474e50a8B0491bb7971770DDc6A763BE' },
];

export default function CreatePoolPage() {
  const [tokenA, setTokenA] = useState('');
  const [tokenB, setTokenB] = useState('');
  const [rate, setRate] = useState('1');
  const [isCreating, setIsCreating] = useState(false);
  const { writeContractAsync, isPending } = useWriteContract();

  const { isConnected, chain } = useAccount();

  console.log("Connected chain:", chain);

  const handleCreatePair = async () => {
    if (!isConnected) {
      alert('Please connect your wallet first');
      return;
    }

    if (!tokenA || !tokenB || !rate) return alert('Fill all fields');
    if (tokenA === tokenB) return alert('Tokens must be different');

    setIsCreating(true);
    console.log('Creating pair with:', { tokenA, tokenB, rate });

    try {
      const parsedRate = parseUnits(rate, 18);
      console.log('Parsed rate:', parsedRate.toString());
      
      console.log('Preparing to send transaction...');
      console.log('Contract address:', FACTORY_ADDRESS);
      console.log('Contract ABI:', contracts.MiniSwapFactory.abi);
      
      const tx = await writeContractAsync({
        address: FACTORY_ADDRESS,
        abi: contracts.MiniSwapFactory.abi,
        functionName: 'createPair',
        args: [tokenA as `0x${string}`, tokenB as `0x${string}`, parsedRate],
      });

      console.log('Transaction sent:', tx);
      alert('Pair created! Transaction hash: ' + tx);
    } catch (error: unknown) {
      console.error('Failed to create pair:', error);
      if (error instanceof Error) {
        console.error('Error name:', error.name);
        console.error('Error message:', error.message);
        console.error('Error stack:', error.stack);
      }
      const errorMessage = error instanceof Error 
        ? error.message 
        : typeof error === 'object' && error !== null && 'shortMessage' in error
          ? (error as { shortMessage: string }).shortMessage
          : 'Failed to create pair';
      alert(errorMessage);
    } finally {
      console.log('Transaction process completed, resetting state');
      setIsCreating(false);
    }
  };

  return (
    <section className="max-w-xl mx-auto p-6 border rounded-xl mt-10 bg-white/5">
      <h2 className="text-xl font-bold mb-6 text-center">Create Token Pool</h2>

      <div className="space-y-4">
        <select className="w-full p-2 border rounded" value={tokenA} onChange={(e) => setTokenA(e.target.value)}>
          <option value="">Select Token A</option>
          {TOKENS.map((token) => (
            <option key={token.address} value={token.address}>
              {token.name}
            </option>
          ))}
        </select>

        <select className="w-full p-2 border rounded" value={tokenB} onChange={(e) => setTokenB(e.target.value)}>
          <option value="">Select Token B</option>
          {TOKENS.map((token) => (
            <option key={token.address} value={token.address}>
              {token.name}
            </option>
          ))}
        </select>

        <input type="number" placeholder="Rate (e.g. 1.5)" value={rate} onChange={(e) => setRate(e.target.value)} className="w-full p-2 border rounded" />

        <button 
          className="w-full bg-primary hover:bg-primary/80 text-white py-2 rounded" 
          onClick={handleCreatePair} 
          disabled={isPending || isCreating}
        >
          {isPending || isCreating ? 'Creating...' : 'Create Pool'}
        </button>
      </div>
    </section>
  );
}