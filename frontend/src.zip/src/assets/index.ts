import logo from './logo.png';
import hero from './animations/hero-animation.json';
import swap from './animations/swap-animation.json';

export { logo, hero, swap };